const users = require("../routes/usersRoute");

module.exports = function (app) {
    app.use("/api/users", users);
};