exports.getAllUsers = async function (req, res) {
    try {
        setTimeout((() => res.status(200).json(mockUsers())),2000)
    } catch (e) {
        res.status(500).send({
            message: e.message || "failed load mock users"
        });
    }
};

const mockUsers = () => {
    return {
        users_list: [
            {name: "Avi", age: 20, subject: "Flutter"},
            {name: "Sahar", age: 20, subject: "Falfel"},
            {name: "Moshe", age: 20, subject: "cackes"},
        ]
    };
};


