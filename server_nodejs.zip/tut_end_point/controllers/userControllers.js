exports.getAllUsers = async function (req, res) {
    try {
        setTimeout((() => res.status(200).json(mockUsers())),2000)
    } catch (e) {
        res.status(500).send({
            message: e.message || "failed load mock users"
        });
    }
};

const mockUsers = () => {
    return {
        users_list: [
            {id:1,name: "Avi", age: 20, subject: "Flutter"},
            {id:2,name: "Sahar", age: 20, subject: "Falfel"},
            {id:3,name: "Moshe", age: 20, subject: "cackes"},
        ]
    };
};


